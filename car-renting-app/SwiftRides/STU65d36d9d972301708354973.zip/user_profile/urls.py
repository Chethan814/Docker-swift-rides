from django.urls import path , include
from user_profile import views

urlpatterns = [

    
]
